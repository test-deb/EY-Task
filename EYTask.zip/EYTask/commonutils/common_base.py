import inspect
import json
import logging
import os

from datetime import datetime

import requests

from commonutils.read_config_files import ReadConfigFiles


class CommonBase:

    @staticmethod
    def launch_test_url(base_url, end_point):
        return (ReadConfigFiles.get_base_url(base_url) +
                ReadConfigFiles.get_end_point(end_point))

    @staticmethod
    def get_request(url, id="", params=None):
        return requests.get(url+id, params=params)

    @staticmethod
    def covert_response_to_text(response):
        return json.load(response.text)

    @staticmethod
    def post_requests(url, data, json):
        return requests.post(url, data=data, json=json)

    @staticmethod
    def put_requests(url, user_id="", data=None, json=None):
        return requests.put(url+user_id, data=data, json=json)

    @staticmethod
    def delete_request(url, user_id="", params=None):
        return requests.delete(url+id, params=params)

    @staticmethod
    def get_status_code(response):
        return response.status_code

    def capture_logs(self):
        test_name = inspect.stack()[1][3]
        logger = logging.getLogger(test_name)
        formatter = logging.Formatter(
            '%(asctime)s: %(levelname)s: %(name)s: %(message)s')
        is_exist = os.path.exists("Logs")
        if not is_exist:
            os.mkdir("Logs")
        time_stamp = datetime.now().strftime("%m_%d_%Y %H_%M_%S")
        file_handler = logging.FileHandler(
            "{0}/{1}.log".format("Logs", f"{time_stamp}_{test_name}"))
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        logger.setLevel(logging.DEBUG)
        return logger
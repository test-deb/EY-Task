import csv

import json


class ReadCSVFiles:

    @staticmethod
    def convert_csv_data_to_user_json_data():
        json_data = []
        with open('..//data//User_Data.csv', mode='r') as file:
            csv_file = csv.reader(file)
            for lines in csv_file:
                user_details = {}
                lines_data = lines[0].split("; ")
                user_details['name'] = lines_data[0]
                user_details['age'] = int(lines_data[1])
                user_details['name'] = lines_data[2]
                json_data.append(user_details)
        return json_data

import configparser

conf = configparser.RawConfigParser()
conf.read('..//Configurations//urlconfig.ini')


class ReadConfigFiles:

    @staticmethod
    def get_base_url(page_name):
        return conf.get("BaseUrl", page_name)

    @staticmethod
    def get_end_point(end_point_name):
        return conf.get("EndPoint", end_point_name)

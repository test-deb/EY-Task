1. Install Python 3.9
2. Go to the EYTask directory. Open command prompt in the same directory.
3. Enter "pip install -r requirements.txt"
4. To run the scripts "pytest tests "
5. Go to Tests/Logs to check the logs.
from commonutils.common_base import CommonBase
from commonutils.read_csv_files import ReadCSVFiles


class TestPost(CommonBase):

    def test_adding_users(self):
        logs = self.capture_logs()
        get_url = self.launch_test_url("user_url", "get_users")
        logs.info("URL Launched")
        get_res = self.get_request(get_url)
        total_user = len(get_res.json())
        logs.info("Response Code:" + str(self.get_status_code(get_res)))
        logs.info("Total number of user is: " + str(total_user))
        json_data = ReadCSVFiles.convert_csv_data_to_user_json_data()
        post_url = self.launch_test_url("user_url", "create_users")
        total_adding_data = len(json_data)
        for jd in json_data:
            post_res = self.post_requests(post_url, data=None, json=jd)
            logs.info("Response Code:" + str(self.get_status_code(post_res)))
            assert self.get_status_code(post_res) == 201
        get_res = self.get_request(get_url)
        total_user_after_adding = len(get_res.json())
        logs.info("Response Code:" + str(self.get_status_code(get_res)))
        assert total_user_after_adding == total_user + total_adding_data
        logs.info("Total number of user is: " + str(
            total_user + total_adding_data))

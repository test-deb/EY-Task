import pytest

from commonutils.common_base import CommonBase
from commonutils.read_csv_files import ReadCSVFiles


class TestDelete(CommonBase):

    @pytest.mark.parametrize("id_delete", ['674a076429ef8a03e8f25f5b'])
    def test_delete_users(self, id_delete):
        logs = self.capture_logs()
        get_url = self.launch_test_url("user_url", "get_users")
        logs.info("URL Launched")
        get_res = self.get_request(get_url)
        total_user = len(get_res.json())
        logs.info("Response Code:" + str(self.get_status_code(get_res)))
        logs.info("Total number of user is: " + str(total_user))
        del_url = self.launch_test_url("user_url", "delete_users")
        del_res = self.delete_request(del_url, user_id=id_delete, params=None)
        logs.info("Response Code:" + str(self.get_status_code(del_res)))
        assert self.get_status_code(del_res) == 200
        get_res = self.get_request(get_url)
        total_user_after_delete = len(get_res.json())
        logs.info("Response Code:" + str(self.get_status_code(get_res)))
        assert total_user_after_delete == total_user-1
        logs.info("Total number of user is: " + str(total_user-1))

import os

isExist = os.path.exists("Logs")
os.mkdir("Logs")
print(isExist)
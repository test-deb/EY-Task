import pytest

from commonutils.common_base import CommonBase
from commonutils.read_csv_files import ReadCSVFiles


class TestPost(CommonBase):

    @pytest.mark.parametrize("id_put", ['674a076429ef8a03e8f25f5b'])
    def test_put_users(self, id_put):
        logs = self.capture_logs()
        put_url = self.launch_test_url("user_url", "put_users")
        logs.info("URL Launched")
        json_data = {"name": "xyz", "age": 33, "colour": "red"}
        put_res = self.put_requests(put_url, user_id=id_put, json=json_data)
        logs.info("Response Code:" + str(self.get_status_code(put_res)))
        assert self.get_status_code(put_res) == 200
        get_url = self.launch_test_url("user_url", "get_users")
        get_res = self.get_request(get_url)
        assert get_res.json()[0] == json_data

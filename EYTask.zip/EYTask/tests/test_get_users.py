from commonutils.common_base import CommonBase


class TestGetUsers(CommonBase):

    def test_fetch_total_users(self):
        logs = self.capture_logs()
        url = self.launch_test_url("user_url", "get_users")
        logs.info("URL Launched")
        res = self.get_request(url)
        logs.info("Response: " + str(res.json()))
        logs.info("Response Code:" + str(self.get_status_code(res)))
        assert self.get_status_code(res) == 200
        logs.info("Total number of user is: " + str(len(res.json())))
